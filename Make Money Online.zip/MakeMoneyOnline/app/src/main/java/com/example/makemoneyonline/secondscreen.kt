package com.example.makemoneyonline

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class secondscreen : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_screen)

        val nextsecbutton = findViewById<Button>(R.id.nextsecond)
        nextsecbutton.setOnClickListener {
            val intent = Intent(this,thirdscreen::class.java)
            startActivity(intent)
        }
        val skipbutton = findViewById<TextView>(R.id.skipButton)
        skipbutton.setOnClickListener {
            val intent = Intent(this,thirdscreen::class.java)
            startActivity(intent)
        }
    }
}