package com.example.makemoneyonline

import ListModel
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ListAdapter(private val context: Context, listModelArrayList: ArrayList<ListModel>) :
    RecyclerView.Adapter<ListAdapter.Viewholder>() {

    var onItemClick: ((ListModel) -> Unit)? = null

    private val listModelArrayList: ArrayList<ListModel>
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListAdapter.Viewholder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.activity_list_view, parent, false)
        return Viewholder(view)
    }

    override fun onBindViewHolder(holder: ListAdapter.Viewholder, position: Int) {
        val model: ListModel = listModelArrayList[position]
        holder.listtext.setText(model.list_name())
        holder.listimage.setImageResource(model.list_image())
        holder.itemView.setOnClickListener {
            onItemClick?.invoke(model)

            var intent = Intent()
            when (position) {
                0 -> {
                    intent = Intent(context, AffilateMarketing::class.java)
                    context.startActivity(intent)
                }

                1 -> {
                    intent = Intent(context, youtube::class.java)
                    context.startActivity(intent)
                }

                2 -> {
                    intent = Intent(context,Blogging::class.java)
                    context.startActivity(intent)
                }

                3 -> {
                    intent = Intent(context,Fiverr::class.java)
                    context.startActivity(intent)
                }

                4 -> {
                    intent = Intent(context,Ebay::class.java)
                    context.startActivity(intent)
                }

                5 -> {
                    intent = Intent(context,Amazon::class.java)
                    context.startActivity(intent)
                }

                6 -> {
                    intent = Intent(context,CpaMarketing::class.java)
                    context.startActivity(intent)
                }

                7 -> {
                    intent = Intent(context,ArtCrafts::class.java)
                    context.startActivity(intent)
                }

                8 -> {
                    intent = Intent(context,leapforce::class.java)
                    context.startActivity(intent)
                }

                9 -> {
                    intent = Intent(context,WordPress::class.java)
                    context.startActivity(intent)
                }

                10 -> {
                    intent = Intent(context,MobileApp::class.java)
                    context.startActivity(intent)
                }

                11 -> {
                    intent = Intent(context,EmailMarketing::class.java)
                    context.startActivity(intent)
                }

                12 -> {
                    intent = Intent(context,FacebookMarketing::class.java)
                    context.startActivity(intent)
                }

                13 -> {
                    intent = Intent(context,BookReview::class.java)
                    context.startActivity(intent)
                }

                14 -> {
                    intent = Intent(context,CopyWriting::class.java)
                    context.startActivity(intent)
                }

                15 -> {
                    intent = Intent(context,Podcast::class.java)
                    context.startActivity(intent)
                }

                16 -> {
                    intent = Intent(context,DocumentTranslation::class.java)
                    context.startActivity(intent)
                }

                17 -> {
                    intent = Intent(context,BecomeTutor::class.java)
                    context.startActivity(intent)
                }

                18 -> {
                    intent = Intent(context,Udemy::class.java)
                    context.startActivity(intent)
                }

                19 -> {
                    intent = Intent(context,photography::class.java)
                    context.startActivity(intent)
                }

                20 -> {
                    intent = Intent(context,Article::class.java)
                    context.startActivity(intent)
                }

                21 -> {
                    intent = Intent(context,SocialMedia::class.java)
                    context.startActivity(intent)
                }

                22 -> {
                    intent = Intent(context,Captioner::class.java)
                    context.startActivity(intent)
                }

                23 -> {
                    intent = Intent(context,Proofreader::class.java)
                    context.startActivity(intent)
                }

                24 -> {
                    intent = Intent(context,ghostwriter::class.java)
                    context.startActivity(intent)
                }

                25 -> {
                    intent = Intent(context,GraphicDesigner::class.java)
                    context.startActivity(intent)
                }

                26 -> {
                    intent = Intent(context,VoiceActing::class.java)
                    context.startActivity(intent)
                }

                27 -> {
                    intent = Intent(context,InstagramMarketing::class.java)
                    context.startActivity(intent)
                }

                28 -> {
                    intent = Intent(context,DropShipping::class.java)
                    context.startActivity(intent)
                }

                29 -> {
                    intent = Intent(context,PaidTweeting::class.java)
                    context.startActivity(intent)
                }

                30 -> {
                    intent = Intent(context,RateMusic::class.java)
                    context.startActivity(intent)
                }

                31 -> {
                    intent = Intent(context,ResearchAssistant::class.java)
                    context.startActivity(intent)
                }

                32 -> {
                    intent = Intent(context,SellPrint::class.java)
                    context.startActivity(intent)
                }

                33 -> {
                    intent = Intent(context,VideoCreation::class.java)
                    context.startActivity(intent)
                }

                34 -> {
                    intent = Intent(context,ViralWebsite::class.java)
                    context.startActivity(intent)
                }

                35 -> {
                    intent = Intent(context,WritePoetry::class.java)
                    context.startActivity(intent)
                }

                36 -> {
                    intent = Intent(context,TravelWriter::class.java)
                    context.startActivity(intent)
                }

                37 -> {
                    intent = Intent(context,SellingPlr::class.java)
                    context.startActivity(intent)
                }

                38 -> {
                    intent = Intent(context,Domain::class.java)
                    context.startActivity(intent)
                }

                39 -> {
                    intent = Intent(context,SellPhoto::class.java)
                    context.startActivity(intent)
                }

                40 -> {
                    intent = Intent(context,Freelancer::class.java)
                    context.startActivity(intent)
                }
            }

        }
    }

    class Viewholder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val listimage: ImageView
        val listtext: TextView

        init {
            listimage = itemView.findViewById(R.id.ListImage)
            listtext = itemView.findViewById(R.id.ListName)
        }

    }

    override fun getItemCount(): Int {
        return listModelArrayList.size
    }

    init {
        this.listModelArrayList = listModelArrayList
    }
}