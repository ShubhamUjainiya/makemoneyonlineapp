package com.example.makemoneyonline

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class firstscreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_screen)

        val nextbutton = findViewById<Button>(R.id.next)
        nextbutton.setOnClickListener {
            val intent = Intent(this,secondscreen::class.java)
            startActivity(intent)
        }
        val skipbutton = findViewById<TextView>(R.id.skipButton)
        skipbutton.setOnClickListener {
            val intent = Intent(this,thirdscreen::class.java)
            startActivity(intent)
        }
    }
}