package com.example.makemoneyonline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DropShipping : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drop_shipping)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.title = "Start Dropshipping"
    }
}