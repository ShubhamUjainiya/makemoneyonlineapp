package com.example.makemoneyonline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ViralWebsite : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viral_website)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.title = "Create a Viral Website"
    }
}