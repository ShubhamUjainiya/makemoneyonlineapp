import android.os.Parcel
import android.os.Parcelable

class ListModel(private var list_name: String?, private var list_image: Int) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readInt()
    ) {
    }

    // Getter and Setter
    fun list_name(): String? {
        return list_name
    }

    fun setlist_name(list_name: String) {
        this.list_name = list_name
    }

    fun list_image(): Int {
        return list_image
    }

    fun setlist_image(list_image: Int) {
        this.list_image = list_image
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(list_name)
        parcel.writeInt(list_image)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ListModel> {
        override fun createFromParcel(parcel: Parcel): ListModel {
            return ListModel(parcel)
        }

        override fun newArray(size: Int): Array<ListModel?> {
            return arrayOfNulls(size)
        }
    }
}