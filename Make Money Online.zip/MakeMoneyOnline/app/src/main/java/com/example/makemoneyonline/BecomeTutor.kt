package com.example.makemoneyonline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class BecomeTutor : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_become_tutor)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.title = "Become Online Tutor"
    }
}