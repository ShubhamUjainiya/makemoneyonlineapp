package com.example.makemoneyonline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Domain : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_domain)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.title = "Buy and Sell Domain"
    }
}