package com.example.makemoneyonline

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Proofreader : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proofreader)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.title = "Be a Profreader"
    }
}