package com.example.makemoneyonline
import ListModel
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        drawerLayout = findViewById(R.id.navigation_drawer)
        actionBarDrawerToggle = ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)

        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val courseRV = findViewById<RecyclerView>(R.id.recycle)

        val listModelArrayList: ArrayList<ListModel> = ArrayList<ListModel>()
        listModelArrayList.add(ListModel("Affilate Marketing",  R.drawable.marketing))
        listModelArrayList.add(ListModel("You Tube",  R.drawable.youtube))
        listModelArrayList.add(ListModel("Blogging",  R.drawable.blogging))
        listModelArrayList.add(ListModel("Fiverr",  R.drawable.fiverr))
        listModelArrayList.add(ListModel("Ebay",  R.drawable.ebay))
        listModelArrayList.add(ListModel("Amazon",  R.drawable.amazon))
        listModelArrayList.add(ListModel("CPA Marketing",  R.drawable.cpa))
        listModelArrayList.add(ListModel("Sell Art and Crafts",  R.drawable.artcrafts))
        listModelArrayList.add(ListModel("Join Leapforce",  R.drawable.leapforce))
        listModelArrayList.add(ListModel("WordPress",  R.drawable.wordpress))
        listModelArrayList.add(ListModel("Mobile Apps",  R.drawable.mobile))
        listModelArrayList.add(ListModel("Email Marketing",  R.drawable.email))
        listModelArrayList.add(ListModel("Facebook Marketing",  R.drawable.facebook))
        listModelArrayList.add(ListModel("Book Review",  R.drawable.bookreview))
        listModelArrayList.add(ListModel("Copy Writing",  R.drawable.copywriting))
        listModelArrayList.add(ListModel("Start Your Podcast",  R.drawable.youpodcast))
        listModelArrayList.add(ListModel("Document Translation",  R.drawable.documenttranslation))
        listModelArrayList.add(ListModel("Become Online Tutor",  R.drawable.tutor))
        listModelArrayList.add(ListModel("Udemy",  R.drawable.udemy))
        listModelArrayList.add(ListModel("Phone Photography", R.drawable.phonephotography))
        listModelArrayList.add(ListModel("Write Article",  R.drawable.articles))
        listModelArrayList.add(ListModel("Social Media",  R.drawable.socialmedia))
        listModelArrayList.add(ListModel("Become a Captioner",  R.drawable.captioner))
        listModelArrayList.add(ListModel("Be a Profreader",  R.drawable.proofrader))
        listModelArrayList.add(ListModel("Become a Ghostwriter",  R.drawable.ghost))
        listModelArrayList.add(ListModel("Graphic Designer",  R.drawable.graphicdesigner))
        listModelArrayList.add(ListModel("Voice Acting",  R.drawable.voiceacting))
        listModelArrayList.add(ListModel("Instagram Marketing",  R.drawable.instagram))
        listModelArrayList.add(ListModel("Start Dropshipping",  R.drawable.dropshipping))
        listModelArrayList.add(ListModel("Paid For Tweeting",  R.drawable.tweeting))
        listModelArrayList.add(ListModel("Listen And Rate Music",  R.drawable.ratemusic))
        listModelArrayList.add(ListModel("Research Assistant",  R.drawable.researchassistant))
        listModelArrayList.add(ListModel("Sell Quote Print",  R.drawable.pritables))
        listModelArrayList.add(ListModel("Video Creation",  R.drawable.video))
        listModelArrayList.add(ListModel("Create Viral Website",  R.drawable.viralwebsite))
        listModelArrayList.add(ListModel("Write Poetry",  R.drawable.poetry))
        listModelArrayList.add(ListModel("Become a Travel Writer",  R.drawable.travel))
        listModelArrayList.add(ListModel("Selling PLR",  R.drawable.plr))
        listModelArrayList.add(ListModel("Buy and Sell Domain",  R.drawable.domain))
        listModelArrayList.add(ListModel("Click And Sell Photos",  R.drawable.sellphotos))
        listModelArrayList.add(ListModel("Become a Freelancer",  R.drawable.freelancer))



        val listAdapter = ListAdapter(this, listModelArrayList)
        val linearLayoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        courseRV.layoutManager = linearLayoutManager
        courseRV.adapter = listAdapter

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }
}